
def reheap_down(elements, root, bottom):
    '''[2]'''
    leftChild = root * 2 + 1
    rightChild = root * 2 + 2
    if leftChild <= bottom:
        if leftChild == bottom:
            maxChild = leftChild
        else:
            if elements[leftChild] <= elements[rightChild]:
                maxChild = rightChild
            else:
                maxChild = leftChild
        if elements[root] < elements[maxChild]:
            elements[root], elements[maxChild] = elements[maxChild], elements[root]
            reheap_down(elements, maxChild, bottom)

def heap_sort(values, numValues):
    '''[3]'''
    index = int(numValues / 2) - 1
    while index >= 0:
        reheap_down(values, index, numValues - 1)
        index -= 1
    
    index = numValues - 1
    while index >= 1:
        values[0], values[index] = values[index], values[0]
        reheap_down(values, 0, index - 1)
        index -= 1
