def insertion_sort(values):
    
    '''[4]'''
    
