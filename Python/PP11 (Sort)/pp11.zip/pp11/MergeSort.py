def merge_sort(values, first, last):
    
    '''[5]'''
    


def merge(values, leftFirst, leftLast, rightFirst, rightLast):

    '''[6]'''

