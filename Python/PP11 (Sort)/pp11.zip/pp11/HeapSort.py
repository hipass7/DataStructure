
def reheap_down(elements, root, bottom):
    '''[2]'''

def heap_sort(values, numValues):

    '''[3]'''
