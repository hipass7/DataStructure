def split(values, first, last):
    '''[7]'''
    
def quick_sort(values, first, last):
    '''[8]'''
