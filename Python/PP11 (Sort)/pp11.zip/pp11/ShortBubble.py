
def short_bubble(values, numValues):
    '''[10]'''

def bubble_up(values, startIndex, endIndex, sort):
    '''[11]'''
