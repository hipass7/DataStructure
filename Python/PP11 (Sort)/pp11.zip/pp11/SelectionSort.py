
def selection_sort(values):

    '''[9]'''
